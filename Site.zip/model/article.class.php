<?php
  class Article {
    public $ref;
    public $prix;
    public $liblle;
    public $description;
    public $image;
    public $categorie;

}
?>