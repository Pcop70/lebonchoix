<?php
    // Partie principale
    // Inclusion du modèle
    include_once("../model/DAO.class.php");
    //var_dump($articles);

    $path = null;
    if(isset($_GET['ref'])){
      $article = $dao->getN($_GET['ref'],1)[0];
      require '../view/article.php'; 
    }else{
      require '../view/acceuil.php';  
    }

    // Article suivant

    // Les articles précédents

    //
    // Charge la vue
  
    ?>
